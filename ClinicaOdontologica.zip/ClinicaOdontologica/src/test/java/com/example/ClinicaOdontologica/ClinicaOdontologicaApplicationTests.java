package com.example.ClinicaOdontologica;

class ClinicaOdontologicaApplicationTests {}
