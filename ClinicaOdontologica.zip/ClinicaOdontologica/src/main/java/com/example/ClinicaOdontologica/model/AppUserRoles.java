package com.example.ClinicaOdontologica.model;

public enum AppUserRoles {
    USER,ADMIN
}
